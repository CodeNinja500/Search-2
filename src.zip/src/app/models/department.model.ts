export interface DepartmentModel {
  readonly name: string;
  readonly id: string;
}
