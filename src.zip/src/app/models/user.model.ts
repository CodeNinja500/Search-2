export interface UserModel {
  readonly id: string;
  readonly email: string;
  readonly roleId: number;
  readonly departmentId: number;
}
